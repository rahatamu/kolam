
package servlets;

import services.*;
import model.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class RegisterServlet extends HttpServlet {

  
   
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         String name=request.getParameter("name");
        String email=request.getParameter("email");
       String password=request.getParameter("password");
       PrintWriter out=response.getWriter();
       RegisterModel model=new RegisterModel();
       model.setName(name);
       model.setEmail(email);
       model.setPassword(password);
       
      // out.println(model.getName()+" "+model.getEmail()+" "+model.getPassword());
       try{
           RegisterServices services=new RegisterServices();
           int check=services.Register(model);
           if(check==1)
           {
               out.println("inserted Successfully");
           }
           else
           {
               out.println("inserted Not Successfully");
           }
    }   catch (ClassNotFoundException ex) {
            Logger.getLogger(RegisterServlet.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(RegisterServlet.class.getName()).log(Level.SEVERE, null, ex);
        }

   
    
    }

}
