/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import utils.*;
import model.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class RegisterServices {
    Connection connection=null;
    public RegisterServices() throws ClassNotFoundException,SQLException
    {
        connection=new ConnectionDb().getSqlConnection();
    }
    public int Register(RegisterModel model)throws SQLException
    {
       PreparedStatement preparedStatement=null;
       preparedStatement=connection.prepareStatement("insert into register(Name,Email,Password) values(?,?,?)");
       preparedStatement.setString(1,model.getName());
       preparedStatement.setString(2,model.getEmail());
       preparedStatement.setString(3,model.getPassword());
       int check=preparedStatement.executeUpdate();
       return check;
    }
}
